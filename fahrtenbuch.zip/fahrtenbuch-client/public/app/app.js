var app = angular.module("fahrtenbuch", []);

app.controller("HomeController", function ($scope, $http) {
  $scope.message = "Hallo VeganArmy!!!!!";

  $http.get("http://localhost:3000/fahrten").then(function (response) {
    $scope.fahrten = response.data;
  });

  $scope.privateKm = function (fahrt) {
    if (fahrt.privat) {
      return fahrt.kmEnde - fahrt.kmStart;
    }
    return 0;
  };

  $scope.geschaeftlicheKm = function (fahrt) {
    if (fahrt.privat) {
      return 0;
    }
    return fahrt.kmEnde - fahrt.kmStart;
  };
});

require('../models/fahrt');
//CLE: Bibliotheken = mongoose | underscore
var mongoose = require('mongoose');
var _ = require('underscore');

var Fahrt = mongoose.model("Fahrt");

//CREATE
exports.post = function(req, res){
    var fahrt = new Fahrt(req.body);
    fahrt.save();
    res.jsonp(fahrt);
}

//READ
exports.get = function(req, res){
    Fahrt.find().exec(function(err, fahrten){
        res.jsonp(fahrten);
    }); 
};

//READ
//CLE: Methode zum Auslesen eines einzelnen Objektes
//WICHTIG: Der Wert fahrtenId muss übereinstimmend sein mit dem Wert, der in routes angegeben wird!
exports.show = function(req, res){
    //CLE: RequestObjekt.ParamsObjekt.Parameter: hier fahrtendId
    Fahrt.load(req.params.fahrtenId, function(err, fahrt){
        res.jsonp(fahrt);
    });
}

//UPDATE
exports.put = function(req, res){
    Fahrt.load(req.params.fahrtenId, function(err, fahrt){
       
        fahrt = _.extend(fahrt, req.body);

        fahrt.save(function(err){
            res.jsonp(fahrt);
        })
        
    });
}

//DELETE
exports.delete = function(req, res){
    //CLE: RequestObjekt.ParamsObjekt.Parameter: hier fahrtendId
    Fahrt.load(req.params.fahrtenId, function(err, fahrt){
        fahrt.remove(function(err){
            res.jsonp(fahrt);
        })
    });
}
//CLE: Mongoose ist ein ODM für die MongoDB
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

//CLE: Definition der Tabelle (Schema) FahrtSchema in der Datenbank fahrtenbuch
var FahrtSchema = new Schema({
    created: {
        type: Date,
        default: Date.now
    },
    von: Date,
    bis: Date,
    kmStart: Number,
    kmEnde: Number,
    strecke: String,
    zweck: String,
    privat: Boolean,
    fahrer: String,
    fahrzeug: String
});

FahrtSchema.statics = {
    load: function(id, cb){//cb=CallBack
        this.findOne({_id : id}).exec(cb);
    }
}

//CLE: Zugänglich machen per mongoose für das Projekt als Model 'Fahrt'
mongoose.model('Fahrt', FahrtSchema);
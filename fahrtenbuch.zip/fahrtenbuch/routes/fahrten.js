var express = require('express');
var router = express.Router();

//CLE Zugriff auf die FahrtenController
var fahrten = require('../controller/fahrtenController');

//CLE: Routing bei einem POST über den FahrtenController
//CREATE
router.post('/', fahrten.post);

//READ
router.get('/', fahrten.get);

//READ
router.get('/:fahrtenId', fahrten.show);

//UPDATE
router.put('/:fahrtenId', fahrten.put);

//DELETE
router.delete('/:fahrtenId', fahrten.delete);

module.exports = router;
